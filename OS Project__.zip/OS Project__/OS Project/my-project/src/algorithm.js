// Implementation of CPU scheduling algorithms

// First-Come-First-Served (FCFS)
export function fcfs(processes) {
    const processQueue = [...processes];
    
    // Sort processes by arrival time
    processQueue.sort((a, b) => a.arrivalTime - b.arrivalTime);
    
    const ganttChart = [];
    let currentTime = 0;
    
    for (let i = 0; i < processQueue.length; i++) {
      const process = processQueue[i];
      
      // If the process hasn't arrived yet, update the current time
      if (currentTime < process.arrivalTime) {
        // Add idle time to Gantt chart
        if (process.arrivalTime > currentTime) {
          ganttChart.push({
            id: 'Idle',
            startTime: currentTime,
            endTime: process.arrivalTime,
            color: '#cccccc'
          });
        }
        currentTime = process.arrivalTime;
      }
      
      // Execute process
      ganttChart.push({
        id: process.id,
        startTime: currentTime,
        endTime: currentTime + process.burstTime,
        color: process.color
      });
      
      // Update current time
      currentTime += process.burstTime;
      
      // Update process metrics
      process.completionTime = currentTime;
      process.turnaroundTime = process.completionTime - process.arrivalTime;
      process.waitingTime = process.turnaroundTime - process.burstTime;
    }
    
    return { processes: processQueue, ganttChart };
  }
  
  // Shortest Job First (SJF) - Non-preemptive
  export function sjf(processes) {
    const processQueue = [...processes];
    const n = processQueue.length;
    const ganttChart = [];
    let currentTime = 0;
    let completed = 0;
    const isCompleted = new Array(n).fill(false);
    
    while (completed < n) {
      let shortestJobIndex = -1;
      let shortestBurst = Number.MAX_VALUE;
      
      // Find the process with shortest burst time that has arrived but not completed
      for (let i = 0; i < n; i++) {
        if (!isCompleted[i] && processQueue[i].arrivalTime <= currentTime && processQueue[i].burstTime < shortestBurst) {
          shortestBurst = processQueue[i].burstTime;
          shortestJobIndex = i;
        }
      }
      
      // If no process is available
      if (shortestJobIndex === -1) {
        // Find the next process to arrive
        let nextArrival = Number.MAX_VALUE;
        let nextIndex = 0;
        
        for (let i = 0; i < n; i++) {
          if (!isCompleted[i] && processQueue[i].arrivalTime < nextArrival) {
            nextArrival = processQueue[i].arrivalTime;
            nextIndex = i;
          }
        }
        
        // Add idle time to Gantt chart
        ganttChart.push({
          id: 'Idle',
          startTime: currentTime,
          endTime: nextArrival,
          color: '#cccccc'
        });
        
        currentTime = nextArrival;
      } else {
        // Execute the selected process
        const process = processQueue[shortestJobIndex];
        
        ganttChart.push({
          id: process.id,
          startTime: currentTime,
          endTime: currentTime + process.burstTime,
          color: process.color
        });
        
        currentTime += process.burstTime;
        
        // Update process metrics
        process.completionTime = currentTime;
        process.turnaroundTime = process.completionTime - process.arrivalTime;
        process.waitingTime = process.turnaroundTime - process.burstTime;
        
        isCompleted[shortestJobIndex] = true;
        completed++;
      }
    }
    
    return { processes: processQueue, ganttChart };
  }
  
  // Shortest Remaining Time First (SRTF) - Preemptive
  export function srtf(processes) {
    const processQueue = [...processes];
    const n = processQueue.length;
    const ganttChart = [];
    const remainingTime = processQueue.map(p => p.burstTime);
    
    let currentTime = 0;
    let completed = 0;
    let prevProcess = -1;
    let ganttStart = 0;
    
    while (completed < n) {
      let shortest = -1;
      let minRemaining = Number.MAX_VALUE;
      
      // Find process with minimum remaining time
      for (let i = 0; i < n; i++) {
        if (processQueue[i].completionTime === 0 && 
            processQueue[i].arrivalTime <= currentTime && 
            remainingTime[i] < minRemaining && 
            remainingTime[i] > 0) {
          minRemaining = remainingTime[i];
          shortest = i;
        }
      }
      
      // If no process found
      if (shortest === -1) {
        // Find next arrival
        let nextArrival = Number.MAX_VALUE;
        for (let i = 0; i < n; i++) {
          if (processQueue[i].completionTime === 0 && 
              processQueue[i].arrivalTime < nextArrival) {
            nextArrival = processQueue[i].arrivalTime;
          }
        }
        
        // Add idle time
        if (prevProcess !== -1) {
          ganttChart.push({
            id: processQueue[prevProcess].id,
            startTime: ganttStart,
            endTime: currentTime,
            color: processQueue[prevProcess].color
          });
        }
        
        ganttChart.push({
          id: 'Idle',
          startTime: currentTime,
          endTime: nextArrival,
          color: '#cccccc'
        });
        
        currentTime = nextArrival;
        ganttStart = currentTime;
        prevProcess = -1;
      } else {
        // If process changed
        if (prevProcess !== shortest) {
          if (prevProcess !== -1) {
            ganttChart.push({
              id: processQueue[prevProcess].id,
              startTime: ganttStart,
              endTime: currentTime,
              color: processQueue[prevProcess].color
            });
          }
          ganttStart = currentTime;
          prevProcess = shortest;
        }
        
        // Execute one time unit
        remainingTime[shortest]--;
        currentTime++;
        
        // Check if process completed
        if (remainingTime[shortest] === 0) {
          completed++;
          
          // Add to Gantt chart
          ganttChart.push({
            id: processQueue[shortest].id,
            startTime: ganttStart,
            endTime: currentTime,
            color: processQueue[shortest].color
          });
          
          // Update process metrics
          processQueue[shortest].completionTime = currentTime;
          processQueue[shortest].turnaroundTime = currentTime - processQueue[shortest].arrivalTime;
          processQueue[shortest].waitingTime = processQueue[shortest].turnaroundTime - processQueue[shortest].burstTime;
          
          prevProcess = -1;
          ganttStart = currentTime;
        }
      }
    }
    
    return { processes: processQueue, ganttChart };
  }
  
  // Round Robin (RR)
  export function roundRobin(processes, quantum) {
    const processQueue = [...processes];
    const n = processQueue.length;
    const ganttChart = [];
    
    // Remaining burst time for each process
    const remainingTime = processQueue.map(p => p.burstTime);
    
    // Queue of processes ready to execute
    const readyQueue = [];
    let completed = 0;
    let currentTime = 0;
    let index = 0;
    
    // Add processes that have arrived at time 0
    while (index < n && processQueue[index].arrivalTime <= currentTime) {
      readyQueue.push(index);
      index++;
    }
    
    while (completed < n) {
      if (readyQueue.length === 0) {
        // CPU idle, find next process to arrive
        if (index < n) {
          ganttChart.push({
            id: 'Idle',
            startTime: currentTime,
            endTime: processQueue[index].arrivalTime,
            color: '#cccccc'
          });
          
          currentTime = processQueue[index].arrivalTime;
          
          while (index < n && processQueue[index].arrivalTime <= currentTime) {
            readyQueue.push(index);
            index++;
          }
        }
      } else {
        // Get process from ready queue
        const i = readyQueue.shift();
        
        // Calculate time this process will run
        const executeTime = Math.min(quantum, remainingTime[i]);
        
        // Add to Gantt chart
        ganttChart.push({
          id: processQueue[i].id,
          startTime: currentTime,
          endTime: currentTime + executeTime,
          color: processQueue[i].color
        });
        
        // Update time
        currentTime += executeTime;
        
        // Check for new arrivals
        while (index < n && processQueue[index].arrivalTime <= currentTime) {
          readyQueue.push(index);
          index++;
        }
        
        // Update remaining time
        remainingTime[i] -= executeTime;
        
        // Check if process completed
        if (remainingTime[i] === 0) {
          completed++;
          
          // Update process metrics
          processQueue[i].completionTime = currentTime;
          processQueue[i].turnaroundTime = currentTime - processQueue[i].arrivalTime;
          processQueue[i].waitingTime = processQueue[i].turnaroundTime - processQueue[i].burstTime;
        } else {
          // Put back in ready queue
          readyQueue.push(i);
        }
      }
    }
    
    return { processes: processQueue, ganttChart };
  }
  
  // Priority Scheduling (Non-preemptive)
  export function priorityScheduling(processes) {
    const processQueue = [...processes];
    const n = processQueue.length;
    const ganttChart = [];
    let currentTime = 0;
    let completed = 0;
    const isCompleted = new Array(n).fill(false);
    
    while (completed < n) {
      let highestPriorityIndex = -1;
      let highestPriority = Number.MAX_VALUE; // Lower number = higher priority
      
      // Find process with highest priority
      for (let i = 0; i < n; i++) {
        if (!isCompleted[i] && processQueue[i].arrivalTime <= currentTime && processQueue[i].priority < highestPriority) {
          highestPriority = processQueue[i].priority;
          highestPriorityIndex = i;
        }
      }
      
      // If no process is available
      if (highestPriorityIndex === -1) {
        // Find next arrival
        let nextArrival = Number.MAX_VALUE;
        for (let i = 0; i < n; i++) {
          if (!isCompleted[i] && processQueue[i].arrivalTime < nextArrival) {
            nextArrival = processQueue[i].arrivalTime;
          }
        }
        
        // Add idle time
        ganttChart.push({
          id: 'Idle',
          startTime: currentTime,
          endTime: nextArrival,
          color: '#cccccc'
        });
        
        currentTime = nextArrival;
      } else {
        // Execute selected process
        const process = processQueue[highestPriorityIndex];
        
        ganttChart.push({
          id: process.id,
          startTime: currentTime,
          endTime: currentTime + process.burstTime,
          color: process.color
        });
        
        currentTime += process.burstTime;
        
        // Update process metrics
        process.completionTime = currentTime;
        process.turnaroundTime = process.completionTime - process.arrivalTime;
        process.waitingTime = process.turnaroundTime - process.burstTime;
        
        isCompleted[highestPriorityIndex] = true;
        completed++;
      }
    }
    
    return { processes: processQueue, ganttChart };
  }